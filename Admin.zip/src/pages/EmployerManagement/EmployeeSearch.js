import React, { useEffect, useState, useMemo } from "react";
import axios from 'axios';
import Pagination from './Pagination';
import { Container, FormControl, Row, Col } from "react-bootstrap";

const EmployeeSearch = () => {
    const [employee, setEmployee] = useState([]);
    const [totalItems, setTotalItems] = useState(0);
    const [currentPage, setCurrentPage] = useState(1);
    const [search, setSearch] = useState("");

    const ITEMS_PER_PAGE = 50;

    useEffect(() => {
        const getData = () => {

            axios.get("http://localhost:1204/employee_registration")
                .then(response => response.data)
                .then(data => {
                    setEmployee(data);
                    console.log(data);
                });
        };

        getData();
    }, []);
    const onInputChange = value => {
        setSearch(value);
    };
    const employeeData = useMemo(() => {
        let computedEmployee = employee;

        if (search) {
            computedEmployee = computedEmployee.filter(
                employeeDetails =>
                    employeeDetails.name.toLowerCase().includes(search.toLowerCase()) ||
                    employeeDetails.location.toLowerCase().includes(search.toLowerCase()) ||
                    employeeDetails.company.toLowerCase().includes(search.toLowerCase()) ||
                    employeeDetails.position.toLowerCase().includes(search.toLowerCase())
            );
        }

        setTotalItems(computedEmployee.length);

        return computedEmployee.slice(
            (currentPage - 1) * ITEMS_PER_PAGE,
            (currentPage - 1) * ITEMS_PER_PAGE + ITEMS_PER_PAGE
        );
    }, [employee, currentPage, search]);

    return (
        <>
            <Row>&nbsp;</Row>
            <Container fluid={true}>
                <Container className="border border-dark">
                    <FormControl type="text" placeholder="Search" value={search} onChange={e => onInputChange(e.target.value)} className="mr-sm-2"/>
                </Container>
                <Container>
                    <Row>
                        <Col>Order by: <strong>Employer Name</strong> | <strong>Name of Company</strong> | <strong>Date</strong></Col>
                        <Col><strong>Location: </strong><label className="text-primary">Bangalore, Chennai etc..,</label></Col>
                    </Row>
                </Container>
                <Container>
                    <Row>
                        <div style={{"position":"relative","height":"500px","width":"1500px","overflow":"auto","display":"block"}}>
                        {
                            employeeData.map(emp => (
                                <>
                                    <Container className="border border-dark">
                                        <Row>
                                            <Col><strong>{emp.name}</strong></Col>
                                            <Col>Date posted: <label className="text-danger">{emp.date}</label></Col>
                                            <Col>Location: <label className="text-danger">{emp.location}</label></Col>
                                        </Row>
                                        <Row>
                                            <Col>{emp.position}</Col>
                                        </Row>
                                        <Row>
                                            <Col><strong>{emp.company}</strong></Col>
                                        </Row>
                                    </Container>
                                    <Container className="border border-0 border-dark">
                                        <Row>&nbsp;</Row>
                                    </Container>
                                </>
                            ))
                        }
                        </div>
                    </Row>
                </Container>
            </Container>
            <div className="row">
                <div className="col-md-6 d-flex flex-row-reverse">
                    <Pagination total={totalItems} itemsPerPage={ITEMS_PER_PAGE} currentPage={currentPage} onPageChange={page => setCurrentPage(page)}/>
                </div>
            </div>
        </>
    );
};

export default EmployeeSearch;