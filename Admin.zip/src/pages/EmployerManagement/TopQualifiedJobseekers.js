import React, { useState, useContext } from 'react';
import { Accordion, Card, Container, AccordionContext, useAccordionToggle, Row, Col } from 'react-bootstrap';
import { FaMinus, FaPlus } from 'react-icons/fa';

function ContextAwareToggle({ children, eventKey, callback }) {
  const currentEventKey = useContext(AccordionContext);

  const decoratedOnClick = useAccordionToggle(
    eventKey,
    () => callback && callback(eventKey),
  );

  const isCurrentEventKey = currentEventKey === eventKey;

  return (
    <button
      type="button"
      style={{ backgroundColor: isCurrentEventKey ? 'white' : 'lavender' }}
      onClick={decoratedOnClick}
    >
      {children}
    </button>
  );
}

function Example() {
  const [isOpen,setIsopen] = useState(false)
  return (
    <>
      <Row>&nbsp;</Row>
      <Container fluid={true}>
          <Container className="border border-dark rounded-lg">
            <strong>Top Qualified Jobseekers</strong>
            <hr/>
            <Accordion defaultActiveKey="0">
              <Card>
                <Card.Header onClick={() => setIsopen(!isOpen)}>
                  <ContextAwareToggle eventKey="0">
                    {isOpen ? 
                        <FaPlus/>
                        :
                        <FaMinus/>
                    }
                  </ContextAwareToggle>
                </Card.Header>
                <Accordion.Collapse eventKey="0">
                  <Card.Body>Hello! I'm the body</Card.Body>
                </Accordion.Collapse>
              </Card>
              <Card>
                <Card.Header>
                  <ContextAwareToggle eventKey="1">Click me!</ContextAwareToggle>
                </Card.Header>
                <Accordion.Collapse eventKey="1">
                  <Card.Body>Hello! I'm another body</Card.Body>
                </Accordion.Collapse>
                  </Card>
              {/*<Container>
                <Row>
                  <Col onClick={() => setIsopen(!isOpen)}>
                      <Row>
                        <ContextAwareToggle eventKey="0">
                          {
                            isOpen ? <FaMinus/> : <FaPlus/>
                          }
                        </ContextAwareToggle>
                      </Row>
                  </Col>
                </Row>
                        </Container>*/}
            </Accordion>
          </Container>
          <Row>&nbsp;</Row>
      </Container>
    </>
  );
}

export default Example;