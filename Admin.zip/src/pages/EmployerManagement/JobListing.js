import React, { useEffect, useState, useMemo } from "react";
import axios from 'axios';
import Pagination from './Pagination';
import { Container, FormControl, Row, Col, Button } from "react-bootstrap";

const JobListing = () => {
    const [employee, setEmployee] = useState([]);
    const [totalItems, setTotalItems] = useState(0);
    const [currentPage, setCurrentPage] = useState(1);
    const [search, setSearch] = useState("");

    const ITEMS_PER_PAGE = 50;

    useEffect(() => {
        const getData = () => {

            axios.get("http://localhost:1204/job_listing")
                .then(response => response.data)
                .then(data => {
                    setEmployee(data);
                    console.log(data);
                });
        };

        getData();
    }, []);
    const onInputChange = value => {
        setSearch(value);
    };
    const employeeData = useMemo(() => {
        let computedEmployee = employee;

        if (search) {
            computedEmployee = computedEmployee.filter(
                employeeDetails =>
                    employeeDetails.vacancies.toLowerCase().includes(search.toLowerCase()) ||
                    employeeDetails.experience.toLowerCase().includes(search.toLowerCase()) ||
                    employeeDetails.location.toLowerCase().includes(search.toLowerCase())
            );
        }

        setTotalItems(computedEmployee.length);

        return computedEmployee.slice(
            (currentPage - 1) * ITEMS_PER_PAGE,
            (currentPage - 1) * ITEMS_PER_PAGE + ITEMS_PER_PAGE
        );
    }, [employee, currentPage, search]);

    return (
        <>
            <Row>&nbsp;</Row>
            <Container fluid={true}>
                <Container className="border border-dark">
                    <FormControl type="text" placeholder="Search" value={search} onChange={e => onInputChange(e.target.value)} className="mr-sm-2"/>
                </Container>
                <Container>
                    <Row>
                        <Col>Order by: <strong>Skills</strong> | <strong>Company</strong> | <strong>Date</strong></Col>
                        <Col><strong>Location: </strong><label className="text-primary">Bangalore, Chennai etc..,</label></Col>
                    </Row>
                </Container>
                <Container>
                    <Row>
                        <div style={{"position":"relative","height":"500px","width":"1500px","overflow":"auto","display":"block"}}>
                        {
                            employeeData.map(emp => (
                                <>
                                    <Container className="border border-dark">
                                        
                                        <Row>
                                            <Col><strong>{emp.vacancies}</strong></Col>
                                            <Col>Date posted: <label className="text-danger">{emp.date}</label></Col>
                                            <Col>Experience: <label className="text-danger">{emp.experience}</label></Col>
                                            <Col>Location: <label className="text-danger">{emp.location}</label></Col>
                                        </Row>
                                        <Row>
                                            <Col>
                                                <Row><Col><strong className="text-danger">{emp.name}</strong>&nbsp;&nbsp;&nbsp;<label>{emp.position}</label></Col></Row>
                                                <Row><Col><strong>{emp.company}</strong></Col></Row>
                                            </Col>
                                            <Col>
                                                <Button variant="primary" size="lg" block><strong>VIEW TOP QUALIFIED JOBSEEKERS</strong></Button>
                                            </Col>
                                        </Row> 
                                       
                                    </Container>
                                    <Container className="border border-0 border-dark">
                                        <Row>&nbsp;</Row>
                                    </Container>
                                </>
                            ))
                        }
                        </div>
                    </Row>
                </Container>
            </Container>
            <div className="row">
                <div className="col-md-6 d-flex flex-row-reverse">
                    <Pagination total={totalItems} itemsPerPage={ITEMS_PER_PAGE} currentPage={currentPage} onPageChange={page => setCurrentPage(page)}/>
                </div>
            </div>
        </>
    );
};

export default JobListing;