import React from "react";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js";
import "../node_modules/bootstrap/dist/js/bootstrap.bundle.js";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import Header from './components/Header';
import AdminMenu from "./components/AdminMenu";
import EmployeeSearch from "./pages/EmployerManagement/EmployeeSearch";
import JobListing from "./pages/EmployerManagement/JobListing";
import TQJS from "./pages/EmployerManagement/TopQualifiedJobseekers";
import Footer from './components/Footer';

function App() {
  return (
    <div className="App">
        <Router>
            <Header/>
            <AdminMenu/>
            <Switch>
                <Route exact path="/EmployeeSearch" component={EmployeeSearch}/>
                <Route exact path="/JobList" component={JobListing}/>
                <Route exact path="/QualifiedJobseekers" component={TQJS}/>
            </Switch>
            <Footer/>
        </Router>
    </div>
  );
}

export default App;
