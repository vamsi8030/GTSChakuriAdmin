import React from "react";
import "../assets/styles.css";
import { Button, Col, Container, Dropdown, DropdownButton, Row } from "react-bootstrap";
import { FaUserCircle } from "react-icons/fa";

const AdminMenu = () => {
    return(
        <Container fluid>
            <Row className="border border-primary">
                <Col className="main center" lg="2" md="auto">
                    <div className="box center">
                        <div align="center">
                            <FaUserCircle className="icons center"/>
                        </div>
                        <p>
                            <Row><strong>Name:</strong><label className="text-danger">VAMSIKRISHNA</label></Row>
                            <Row><strong>Current Role:</strong><label className="text-danger">ADMIN</label></Row>
                            <Row className="rounded-lg"><Button variant="primary">Switch Role</Button></Row>
                        </p>
                    </div>
                </Col>
                <Col className="border-left border-dark" align="center">
                    <DropdownButton  title="Profile management">
                        <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
                        <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
                        <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
                    </DropdownButton>
                </Col>
                <Col className="border-left border-dark" align="center">
                    <DropdownButton id="dropdown-basic-button" title="Employer management">
                        <Dropdown.Item href="/QualifiedJobseekers">Top Qualified Jobseekers</Dropdown.Item>
                        <Dropdown.Item href="/EmployeeSearch">Employee Search</Dropdown.Item>
                        <Dropdown.Item href="/JobList">Job Listing</Dropdown.Item>
                    </DropdownButton>
                </Col>
                <Col className="border-left border-dark" align="center">
                    <DropdownButton id="dropdown-basic-button" title="Jobseeker management">
                        <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
                        <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
                        <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
                    </DropdownButton>
                </Col>
            </Row>
        </Container>
    );
};

export default AdminMenu;